package com.ob.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class OnlineBanking {
	 static Scanner sc=null;
	 static IOnlineBankingService serobj;
	 static CustomerSignUp csu=null;
	static int openingBalance=0;
	public OnlineBanking() {
		serobj=new OnlineBankingService();
		csu=new CustomerSignUp();
	}
	
	/*  main program  */
	public static void main(String[] args) throws OnlineBankingException {
		
		sc=new Scanner(System.in);
		/* do while loop for infity  */
		
	
		System.out.println("WELCOME TO THE ONLINE BANKING");
		
		System.out.println("******************************");
		System.out.println("1.ACCOUNTHOLDER LOGIN  ");
		System.out.println("2.ADMINISTRATION LOGIN  ");
		
		int option=sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("WELCOME TO ACCOUNT LOGIN");
			
			customerLoginPage();
			break;

		case 2:
			System.out.println("ENTER YOUR USERID");
			int adminuserid=sc.nextInt();
			
			System.out.println("ENTER YOUR PASSWORD");
			String adminpassword=sc.next();
		
			if((adminuserid==1234) && (adminpassword.equals("admin"))) 
			{
			administrationLogin();
			
			}
			else {
				System.out.println("ENTER VALID LOGIN DETAILS");
				
			}
			
		
		default:
			System.out.println("Enter Valid details");
		
		}
	}
	private static void administrationLogin() {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  CREATE NEW ACCOUNT");
		System.out.println("2  --->  VIEW TRANSACTION");
		int adminoption=sc.nextInt();
		boolean result=true;
		
		String mobileNo;
		String eMail;
		int openingBalance;
		String panCard;
		String accountType;
		
		switch (adminoption) {
		case 1:				
			System.out.println("PLEASE ENTER  DETAILS");
			String name;
			do {
			System.out.println("ENTER YOUR NAME ");
		     name=sc.next();
			
			}while(serobj.validatename(name)==false);
			
			System.out.println("ENTER ADDRESS DETAILS");
			String addressDetails=sc.next();
		
			do {
			System.out.println("ENTER MOBILE NUMBER");
			mobileNo=sc.next();
			
			}while(serobj.validatemobileNo(mobileNo)==false);
			
		do {
			System.out.println("ENTER EMAIL ID");
			 eMail=sc.next();
			
		}while(serobj.validateEMail(eMail)==false);
			
		do {
			System.out.println("OPENING BALANCE");
		 openingBalance=sc.nextInt();
			
		}while(serobj.validateOpeningBalance(openingBalance)==false);
		
		do {
			System.out.println("ENTER pan card");
			 panCard=sc.next();
			
		}while(serobj.validatePanCard(panCard)==false);
			
		do {
			System.out.println("enter account type");
			 accountType=sc.next();
			serobj.validateAccountType(accountType);
		}while(serobj.validateAccountType(accountType)==false);
			
			
			int accountId=0;
			NewAccount newAccount= new NewAccount(accountId, name, eMail,mobileNo, addressDetails, accountType, openingBalance, panCard);
		
			try {
				int result1=addinfo(newAccount);
			} catch (OnlineBankingException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}				
			
			System.out.println("WELCOME TO ABC BANK");
			
			break;
        
			  
        case 2:
        	System.out.println("ENTER THE ACCOUNT NUMBER");
        	String acc_num=sc.nextLine();
        	System.out.println("  TRANSACTION PERIOD  ");
        	System.out.println(" PRESS 1  --->  FOR 1 DAY ");
        	System.out.println(" PRESS 2  --->  FOR 1 MONTH ");
        	System.out.println(" PRESS 3  --->  FOR 1 YEAR ");
        	System.out.println(" PRESS 4  --->  ALL TRANSACTION");      	
			
			break;
		default:
			System.out.println("Enter Valid Credentails");
		}
	}
		
	
	public static void customerLoginPage() throws OnlineBankingException {
		System.out.println("1.SIGNIN");
		System.out.println("2.SIGNUP");
	String custpassword=null;
	int custuserid=0;
		int custsignin=sc.nextInt();
		switch (custsignin) {
		case 1:
			int accountId=0;
			int count=0;
		
		     System.out.println("ENTER YOUR USERID");
		     int userid=sc.nextInt();
              System.out.println("ENTER YOUR PASSWORD");
		     String password=sc.next();
		     System.out.println("pwd");
	    /* retrive customer account id using username and password */
		/* pass it in customer Login below */
		  
		   csu=validateCustomerLoginDetails(custuserid,custpassword);
				System.out.println(csu);
		    
		   
		    	 System.out.println("INVALID USERID AND PASSWORD");
		    	 System.out.println("PLEASE ENTER VALID USERID AND PASSWORD");
		    	// count++;
		
		     customerLogin(accountId);
		   //  count=3;	
			 break;
		
		case 2:
		
		     System.out.println("SIGN UP");
		     String custsignup=sc.nextLine();
		     
		     customerSignUp();
		
		  break;
		
		default:
			System.out.println("PLEASE ENTER CORRECT OPTION");
			break;
		}
		
		
	}

	private static CustomerSignUp validateCustomerLoginDetails(int custuserid,String custpassword) throws OnlineBankingException {
		serobj=new OnlineBankingService();
		System.out.println("23254");
		return serobj.validateCustomerLoginDetails(custuserid, custpassword);
	}

	public static void customerLogin(int accountId) throws OnlineBankingException {
		
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1.ACCOUNT BALANCE");
		System.out.println("2.MINI/DETAILED STATEMENTS");
		System.out.println("3.ADDRESS CHANGE REQUEST");
		System.out.println("4.MOBILE NO. CHANGE REQUEST");
		System.out.println("5.CHEQUE BOOK REQUEST");
		System.out.println("6.SERVICE REQUEST TRACKER");
		System.out.println("7.FUND TRANSFER");
		System.out.println("8.CHANGE PASSWORD");
		
		int custoption=sc.nextInt();
		
		String description=null;
		switch (custoption) {
		
		case 1:
		    NewAccount accbal=serobj.customerOpeningBalance(accountId);
			System.out.println("YOUR ACCOUNT BALANCE  :  "+accbal);
			break;
			
        case 2:
        	/*     mini and detailed transaction    */
			
			break;
			
        case 3:
        	System.out.println("ENTER YOUR NEW ADDRESS");
        	description=sc.next();
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	        break;
	        
        case 4:
        	System.out.println("ENTER YOUR NEW MOBILE NUMBER");
        	description=sc.next();
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 5:
        	int acc_id=serobj.serviceTrackerId(accountId);
        	description="NEW CHEQUEBOOK";
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 6:
        	List<ServiceTracker> servicetracker=null;
			
				servicetracker = serobj.retrieveServiceTrackerByAccountId(accountId);
		
			
			for(ServiceTracker st:servicetracker)
			{
			System.out.println(st);	
			}
	 
	        break;
	        
        case 7:
        	int senderAccountNum=accountId;
        	System.out.println("ENETER THE PAYEE ACCOUNT");
        	int payeeAccId=sc.nextInt();
        	System.out.println("ENTER THE TRANSACTION PASSWORD");
        	String transpwd=sc.next();
        	System.out.println("ENTER THE AMOUNT");
        	int transferAmount=sc.nextInt();
        	System.out.println("TRANSACTION TYPE");
        	System.out.println(" 1  --->  NEFT");
        	System.out.println(" 2  --->  RTGS");
        	System.out.println(" 3  --->  IMPS");
        	int choice=sc.nextInt();
        	switch (choice) {
			case 1:
				/*    update amount in payee and payer  */
				/*     enter neft in transaction type  */
				System.out.println("NEFT TRANSACTION SUCCESSFUL");
				break;
				
				
			case 2:
				/*    update amount in payee and payer  */
				/*     enter RTGS in transaction type  */
				System.out.println("RTGS TRANSACTION SUCCESSFUL");
				break;
				
			case 3:
				/*    update amount in payee and payer  */
				/*     enter imps in transaction type  */
				System.out.println("IMPS TRANSACTION SUCCESSFUL");
				break;

			default:
				System.out.println("INVALID CHOICE . PLEASE ENTER CORRECT OPTION");
				break;
			}
        	
       	 
	        break;
	     
        
        case 8:
        	System.out.println("CREATE A NEW PASSWORD FOR USERLOGIN");
        	String loginPassword=sc.next();
        	serobj.updateLoginPassword(accountId,loginPassword);
        	/*    provide  status       */
	
	        break;
        
		default:
			break;
		}
		
		
	}
	
public static void customerSignUp() throws OnlineBankingException {
		
		 csu=new CustomerSignUp();
		 serobj=new OnlineBankingService();
		
		System.out.println("ENTER THE ACCOUNT ID");
		int accountId=sc.nextInt();
		csu.setAccountId(accountId);
		
		System.out.println("CREATE USER NAME");
		int userId=sc.nextInt();
		csu.setUserId(userId);
		
		System.out.println("CREATE PASSWORD");
		String loginPassword=sc.next();
		csu.setLoginPassword(loginPassword);
		
		System.out.println("SECRET QUESTION --> WHEN DO YOU GET HIGH ?");
		String secretQuestion=sc.next();
		csu.setSecretQuestion(secretQuestion);
		
		System.out.println("CREATE TRANSACTION PASSWORD");
		String transactionPassword=sc.next();
		csu.setTransactionPassword(transactionPassword);
		
		System.out.println("CREATE LOCK STATUS ****************************");
		String lockStatus=sc.next();
		csu.setLockStatus(lockStatus);
		int out=serobj.customerSignUp(csu);
		if(out>0) {
			System.out.println("data is inserterd");
		}
		 
	}
private static int addinfo(NewAccount newAccount) throws OnlineBankingException, SQLException {
	
	return serobj.addinfoNewAccount(newAccount);
}

}
