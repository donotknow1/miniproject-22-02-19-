package com.ob.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;

public class OnlineBankingService implements IOnlineBankingService
{
	
	static IOnlineBankingDao daoobj;

	public OnlineBankingService() {
		daoobj=new OnlineBankingDao();
	}
	
	@Override
	public CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException {
	
		return daoobj.validateCustomerLoginDetails(custuserid,custpassword);
	}
	
	@Override
	public NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException {
		return daoobj.customerOpeningBalance(accountId);
	}
	
	//Request for servicetracker
	@Override
	public void Request(int accountId, String description) throws OnlineBankingException {
		daoobj.Request(accountId,description);
		
	}
	
	public List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException{
		return daoobj.retrieveServiceTrackerByAccountId(accountId);
		
	}
	
	@Override
	public int customerSignUp(CustomerSignUp  obs) throws OnlineBankingException {
		return daoobj.customerSignUp(obs);
		
	}
	@Override
    public int updateLoginPassword(int userid,String loginPassword) throws OnlineBankingException {
		
	return daoobj.updateLoginPassword(userid,loginPassword);
	}


	//validation method for user
	
	@Override
	public boolean validateUserId(int userId) {
		Pattern pattern=Pattern.compile("\\d[1-9][0-9]{5}");
		String userid=Integer.toString(userId);
		Matcher matcher=pattern.matcher(userid);
		if(matcher.equals(userid))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid User Id");
			return false;	
		}
		
	}


	@Override
	public boolean validateLoginPassword(String loginPassword) {
		Pattern pattern=Pattern.compile( "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
		Matcher matcher=pattern.matcher(loginPassword);
		if(matcher.equals(loginPassword))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid Login Password");
			System.out.println("Password should have minimum 1 upper case  1 lower case followed by 1 special character and number");
			return false;	
		}
	}


	@Override
	public boolean validateSecretQuestion(String secretQuestion)
	{
		Pattern pattern=Pattern.compile("");
		Matcher matcher=pattern.matcher(secretQuestion);
		if(matcher.equals(secretQuestion))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid Secret Question");
			return false;	
		}
	}


	@Override
	public boolean validateTransactionPassword(String transactionPassword) {
		Pattern pattern=Pattern.compile( "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
		
		Matcher matcher=pattern.matcher(transactionPassword);
		if(matcher.equals(transactionPassword))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid TransactionPassword ");
			System.out.println("Password should have minimum 1 upper case  1 lower case followed by 1 special character and number");
			return false;	
		}
	}


	

	@Override
	public void createAccount(NewAccount newcustomer) {
	
		}


	@Override
	public int serviceTrackerId(int accountId) throws OnlineBankingException {
	
		return daoobj.serviceTrackerId(accountId);
	}


	@Override
	public boolean validatename(String name) {
		 Pattern pattern=Pattern.compile("[A-Z][a-z]{2,15}");
		   Matcher matcher=pattern.matcher(name);
		   if(matcher.matches()) {
		  // log.info("Name Matches"+name);
		    return true;
		   }
		   else
		   {
		   // log.info("Name is not matching");
		    return false;
		   }
		
		
	}


	@Override
	public boolean validatemobileNo(String mobileNo) {
		 Pattern pattern=Pattern.compile("{1}[6-9][0-9]{9}");
		   Matcher matcher=pattern.matcher( mobileNo);
		   if(matcher.matches()) {
		  // log.info("mobile number Matches"+ mobileNumber);
		    return true;
		   }
		   else
		   {
		  //  log.info("moblie number is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validatePanCard(String panCard) {
		Pattern pattern=Pattern.compile("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$");
		   Matcher matcher=pattern.matcher( panCard);
		   if(matcher.matches()) {
		   //log.info("panCard Matches"+panCard);
		    return true;
		   }
		   else
		   {
		    //log.info("pancard is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validateAccountType(String accountType) {
		 if(accountType.equals("savingsaccount")) {
			    accountType="savingsaccount";
			    return true;}
			    else if(accountType.equals("currentaccount")){
			     accountType="Currentaccount";
			     return true;}
			    else {
			     System.out.println("please enter correct details");
			   }
			   return false;
			  }
	


	@Override
	public boolean validateEMail(String eMail) {
		 Pattern pattern=Pattern.compile("[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Za-z]{2,64} ");
		   Matcher matcher=pattern.matcher( eMail);
		   if(matcher.matches()) {
		  // log.info("email Matches"+ eMail);
		    return true;
		   }
		   else
		   {
		    //log.info("email is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validateOpeningBalance(int openingBalance) {
		if(openingBalance==1000) {
		    openingBalance=1000;
		    return true;
		   }
		   else {
		    System.out.println("please enter valid amount");
		   
		   return false;
		  }
	}
	@Override
	public int addinfoNewAccount(NewAccount newAccount) throws OnlineBankingException {
		
		return daoobj.addinfoNewAccount( newAccount) ;
	}

	

	
	
	
	
	
	


}
