package com.ob.service;

import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;

public interface IOnlineBankingService {
	
	abstract CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException;
	abstract NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException;
	abstract void Request(int acc_id, String description) throws OnlineBankingException;
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException;
	abstract int updateLoginPassword(int accountid,String loginPassword) throws OnlineBankingException;
	abstract void createAccount(NewAccount newcustomer);
	abstract int customerSignUp(CustomerSignUp csu) throws OnlineBankingException;
	boolean validateUserId(int userId);
	boolean validateLoginPassword(String loginPassword);
	boolean validateSecretQuestion(String secretQuestion);
	boolean validateTransactionPassword(String transactionPassword);
	abstract int serviceTrackerId(int accountId) throws OnlineBankingException;
	abstract boolean validatename(String name);
	abstract boolean validatemobileNo(String mobileNo);
	abstract boolean validatePanCard(String panCard);
	abstract boolean validateAccountType(String accountType);
	abstract boolean validateEMail(String eMail);
	abstract boolean validateOpeningBalance(int openingBalance);
	int addinfoNewAccount(NewAccount newAccount) throws OnlineBankingException;
	
}
