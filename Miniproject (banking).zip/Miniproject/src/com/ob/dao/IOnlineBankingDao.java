package com.ob.dao;

import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;


public interface IOnlineBankingDao {

	abstract CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException;
	abstract NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException;
	abstract void Request(int acc_id, String description) throws OnlineBankingException;
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException;
	abstract int customerSignUp(CustomerSignUp obs) throws OnlineBankingException;
	abstract int updateLoginPassword(int accountid,String loginPassword) throws OnlineBankingException;
	
	abstract int serviceTrackerId(int accountId) throws OnlineBankingException;
	abstract int addinfoNewAccount(NewAccount newAccount) throws OnlineBankingException;
	
	
	
	

	

	
	
	
	
	
	

	
	
	

	

	

}
