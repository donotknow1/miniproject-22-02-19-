package com.ob.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;
import com.ob.util.DBUtil;


public class OnlineBankingDao implements IOnlineBankingDao{
	Connection conn=null;
	CustomerSignUp customersignup = null;
	NewAccount newAccount =null;
	ServiceTracker serviceTracker=null;
	
	
	public int customerSignUp(CustomerSignUp customersignup) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
	
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Usertable_INSERT_QRY);
			pst.setLong(1,customersignup.getAccountId());
			pst.setInt(2,customersignup.getUserId());
			pst.setString(3, customersignup.getLoginPassword());
			pst.setString(4, customersignup.getSecretQuestion());
			pst.setString(5, customersignup.getTransactionPassword());
			pst.setString(6,customersignup.getLockStatus());
			System.out.println("in  1st dao");
			status=pst.executeUpdate();
			System.out.println("in dao");
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		} 
		return status;
		}
    

	@Override
	public int updateLoginPassword(int userid, String loginPassword) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Customer_INSERT_QRY);
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return userid;
		
		
	}
    @Override
	public CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		System.out.println("nterd in dao");
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_BY_UserID_QRY);
			pst.setInt(1, custuserid);
			pst.setString(2, custpassword);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
			customersignup=new CustomerSignUp(rs.getLong(1), rs.getInt(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
			System.out.println(customersignup);
			}
			System.out.println("in dao 2");
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return customersignup;
	}
    @Override
	public List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException {
		conn=DBUtil.DbConnection();
		List< ServiceTracker> obList=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.RETRIVE_BY_ServiceTrackerID_QRY);
			obList=new ArrayList();
			 ServiceTracker service=null;
			while(rs.next()){
				serviceTracker = new ServiceTracker(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5));
				obList.add(service);
			}
		} catch (SQLException e) {
			throw new OnlineBankingException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return obList;
	}
		

	@Override
	public void Request(int acc_id, String description) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.ServiceTracker_INSERT_QRY);
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
	}

   //Requesting for servicetracker id
	@Override
	public int serviceTrackerId(int accountId) throws OnlineBankingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.ServiceTracker_INSERT_QRY);
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
		}catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		return serviceTrackerId(accountId);
	}


	@Override
	public int addinfoNewAccount(NewAccount newAccount) throws OnlineBankingException {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		int accountId=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Customer_INSERT_QRY);
			pst.setString(1, newAccount.getCustomerName());	
			pst.setString(2, newAccount.getCustomerAddress());
			pst.setString(3, newAccount.getCustomerMobNum());
			pst.setString(4, newAccount.getCustomerEmail());
			pst.setString(5, newAccount.getAccountType());
			pst.setInt(6, newAccount.getOpeningBalance());
			pst.setString(7, newAccount.getPancard());
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
			
			pst=conn.prepareStatement(IQueryMapper.RETRIVE_BY_AccountID_QRY);
			 ResultSet rs=pst.executeQuery();
			 if(rs.next())
			 {
				accountId=rs.getInt(1);
				log.info(accountId);
			 }
			} catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}return accountId;
		
	}


	@Override
	public NewAccount customerOpeningBalance(long accountId) throws OnlineBankingException {
		System.out.println("fdfs");
				PropertyConfigurator.configure("resources/log4j.properties");
				Logger log=Logger.getRootLogger();
				conn=DBUtil.DbConnection();
				int status=0;
				int accbal=0;
				try {
					PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_BY_OPENINGBAL_QRY);
					pst.setInt(1,newAccount.getAccountId());
					System.out.println("new account");
					 ResultSet rs=pst.executeQuery();
					 if(rs.next())
					 {
					NewAccount newAccount = new NewAccount(rs.getInt(7));
						log.info(newAccount);
					 }
					log.info(status+" data is inserted");
				}catch (SQLException e) {
					log.error("data is not stored:: "+e.getMessage());
					throw new OnlineBankingException("data not stored "+e.getMessage());
				}
				
				return newAccount;
			}
	
	
	}



	

